//This is the Header File Section
#include <iostream>
using namespace std;

//main function
int main()
{
//declaration of variables
int maxRoom;
int numPeople;
int difference;

//inputting the max room capacity
cout << "Input the max room capacity: ";
cin >> maxRoom;

//inputting number of people attending
cout << "Input the number of people attending the meeting: ";
cin >> numPeople;

//If statement is used to check how many people can join the meeting
if(numPeople<=maxRoom){
difference=maxRoom-numPeople;
cout << "It is legal to hold the meeting in the room. " << difference << " more people may attend the meeting.";
}

//else if statement is used to check how many people should exit the meeting
else if(numPeople>maxRoom){
difference=numPeople-maxRoom;
cout << "The meeting will not be held due to the fire regulations. " << difference << " people should be excluded in order to meet fire regulations.";
}

return 0;
}
