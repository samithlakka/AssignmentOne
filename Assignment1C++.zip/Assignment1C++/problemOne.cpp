//This is the Header File Section
#include<iostream>
using namespace std;
#define METRICTON 35273.92

//main function
void main(){

//declaration of variables
double ounceses, weight, boxes;

//inputting the weight of the package
cout<<"Enter the weight of the package in ounceses: ";
cin>> ounceses;

//calculating the weight of the package
weight = (ounceses/METRICTON);

//output weight
cout<<"The weight of the package in terms of metric tons: " << endl;
//boxes

boxes = (METRICTON/ounceses);

//output boxes
cout <<"Number of boxes needed for one metric ton of cereal: "<<boxes<<endl;
}
