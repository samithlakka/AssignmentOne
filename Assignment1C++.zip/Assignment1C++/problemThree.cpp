//This is the Header file Section
#include<iostream>
using namespace std;

//main function
int main(){

//declaration of variables
const double POSSIBLE_HOURS = 40.0;
int dependent, hours;
double sstax, fitax, sitax, medins;
double grosspay, nethomepay, withheld;

//input for number of hours worked in a week
cout<<"Input the number of hours worked for the week: "<<endl;
cin>>hours;

//input for the number of dependents
cout<<"Input number of dependents: "<<endl;
cin>>dependent;

//if statement is used to check if hours is above the possible hours
if(POSSIBLE_HOURS < hours)
grosspay = 16.78 * POSSIBLE_HOURS + (1.5)*(16.78)*(hours - POSSIBLE_HOURS);
else
grosspay = 16.78*hours;

//calculating the social security, federal income and state income tax
sstax = .06*grosspay;
fitax = .14*grosspay;
sitax = .05*grosspay;

//calculating withheld amount and net pay
medins = 10;
withheld = sstax + fitax + sitax + medins;
nethomepay = grosspay - withheld;

//outputs for each value requested
cout<<"Gross pay: "<<grosspay<<endl;
cout<<"Withheld amount: "<<withheld<<endl;
cout<<"Net take home pay: "<<nethomepay<<endl;

return 0;
}
